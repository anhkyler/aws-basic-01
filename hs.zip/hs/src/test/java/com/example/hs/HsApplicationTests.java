package com.example.hs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HsApplicationTests {

	@Test
	void contextLoads() {
	}

}
